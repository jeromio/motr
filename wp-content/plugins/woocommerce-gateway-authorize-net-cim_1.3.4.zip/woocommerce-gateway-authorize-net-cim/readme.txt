=== Authorize.net CIM Gateway for WooCommerce ===
Author: skyverge
Requires at least: 3.8
Tested up to: 4.0
Requires WooCommerce at least: 2.1
Tested WooCommerce up to: 2.2

== Description ==

Adds the Authorize.net CIM Payment Gateway to your WooCommerce site, offering support for Subscriptions and more!

See http://docs.woothemes.com/document/authorize-net-cim/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-authorize-net-cim' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
